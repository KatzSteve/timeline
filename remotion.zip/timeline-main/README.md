# Remotion Timeline

![Remotion Timeline Demo](https://remotion-assets.s3.eu-central-1.amazonaws.com/remotion-timeline-banner.jpg)

A highly-customizable, copy-pastable video timeline component from Remotion.

- [Documentation](https://www.remotion.dev/docs/timeline)
- [Demo](https://timeline.remotion.dev)
- [Store page](https://www.remotion.pro/timeline)
